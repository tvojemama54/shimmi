SHIMMI YOLO BIRD – testovací projekt pro online sestavení APK

TENTO ZIP NENÍ APK. Obsahuje pouze zdrojový kód a GitHub Actions postup sestavení.
Sestavení online jsem v tomto prostředí nemohl otestovat.

GitHub Actions workflow .github/workflows/android.yml očekává zdrojové soubory
v rootu repozitáře. Po nahrání do GitHub repozitáře a spuštění workflow
se (pokud build projde) vytvoří ARTIFACT obsahující app-debug.apk.

Z mobilu je potřeba nahrát složky a soubory do repozitáře, např.
přes webové prostředí pro editaci zdrojů. GitHub běžně neumí ZIP automaticky
rozbalit po pouhém nahrání na stránku repozitáře.

POZOR: Není odzkoušené rozpoznávání hry, sbírání peněz a vlajek,
a soutěž může automatizované hraní zakazovat.

Po instalaci je nutné ručně povolit službu Usnadnění přístupu a
opránění pro snímání obrazovky. Aplikace nemá oprávnění pro internet.
