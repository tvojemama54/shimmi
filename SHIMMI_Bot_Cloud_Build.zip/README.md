# SHIMMI · YOLO BIRD — testovací Android bot

**Stav:** experimentální zdrojový projekt, nikoli hotové APK ani garantovaný bot. Detekce překážek ani skóre nejsou otestovány přímo na zařízení; aktualizované motivy hry mohou být rozpoznávány chybně. Zlepšení skóre není zaručeno.

## Co dělá

- Použije systémové oprávnění ke sdílení obrazovky přes `MediaProjection`.
- Analyzuje snímky lokálně v telefonu, přibližně 20× za sekundu.
- Hledá zelenou postavičku a výrazně texturované překážky bez závislosti na jediné barvě trubek.
- Pomocí `AccessibilityService.dispatchGesture` vytváří krátká ťuknutí na displeji.
- V oznámení je kdykoli dostupné **Zastavit**. Nepracuje se serverem, účtem ani skóre.

**Omezení:** Zatím není samostatně implementované spolehlivé rozpoznávání peněz a vlajek, protože se jejich barvy a pozadí mění. Bot tedy nemusí správně vybírat bonusy či se vyhýbat penalizaci. Heuristika pro trubky může chybovat. K prvním reálným pokusům je nutné otestování a doladění.

## Sestavení a spuštění

1. Na počítači otevři složku `ShimmiYoloBot` v Android Studiu (JDK 17, Android SDK 35). Gradle 8.7 a Android Gradle Plugin 8.6.1, Kotlin 2.0.21.
2. Vyber **Build → Build APK(s)** a nainstaluj APK do Androidu 11+.
3. V aplikaci otevři nastavení Usnadnění přístupu a ručně povol službu **SHIMMI Yolo Bot (test)**. Tuto službu povoluj pouze pokud důvěřuješ jejímu zdrojovému kódu.
4. Klepni na **Spustit bota**, v systémovém dialogu zvol **Celá obrazovka**, jinak hra nemusí být zachycena.
5. Přepni se do SHIMMI a spusť YOLO BIRD. Pro konec stáhni oznámení a klepni na **Zastavit**.

## Soukromí a férovost

Program nemá internetová oprávnění a nic nikam neodesílá. Žádná data ze SHIMMI nečte kromě obrazu displeje; neupravuje skóre ani leaderboard. Pokud pravidla soutěže zakazují automatizaci, soutěžní skóre dosažené botem může být neplatné. **Před použitím v žebříčku si přečti RULES ve hře.**

## Další vývoj

Pro skutečně spolehlivý bot je potřeba získat více obrazových vzorků během změn prostředí, určit fyziku letu, implementovat rozpoznání vlajek a peněz a otestovat ovládání na konkrétním telefonu.
